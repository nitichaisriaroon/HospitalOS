sudo -u postgres /hospitalos/PostgreSQL/9.5/bin/psql -c "CREATE USER replicator REPLICATION LOGIN ENCRYPTED PASSWORD '1234';"
